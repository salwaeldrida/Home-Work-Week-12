import React, { useState } from 'react';
import './output.css'

function Square({ value, onClick }) {
  return (
    <button
      className="square bg-white border border-gray-300 w-[150px] h-[150px] flex justify-center items-center font-bold text-5xl"
      onClick={onClick}
    >
      {value}
    </button>
  );
}

function Board() {
  const [squares, setSquares] = useState(Array(9).fill(null));
  const [xIsNext, setXIsNext] = useState(true);

  function selectSquare(i) {
    if (calculateWinner(squares) || squares[i]) {
      return;
    }

    const newSquares = [...squares];
    newSquares[i] = xIsNext ? 'X' : 'O';
    setSquares(newSquares);
    setXIsNext(!xIsNext);
  }

  function renderSquare(i) {
    return <Square value={squares[i]} onClick={() => selectSquare(i)} />;
  }

  function calculateWinner(squares) {
    const lines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];
  
    for (let i = 0; i < lines.length; i++) {
      const [a, b, c] = lines[i];
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
  
    return null;
  }

  const winner = calculateWinner(squares);
  let status;
  if (winner) {
    status = `Winner: ${winner}`;
  } else if (squares.every(Boolean)) {
    status = `Scratch: Cat's game`;
  } else {
    status = `Next Player Run: ${xIsNext ? 'X' : 'O'}`;
  }

  function restart() {
    setSquares(Array(9).fill(null));
    setXIsNext(true);
  }

  return (
    <div className="p-4">
      <div className="text-5xl font-bold mb-10 text-center text-[#26FFCB]">{status}</div>
      <div className="grid grid-cols-3 gap-5">
        {renderSquare(0)}
        {renderSquare(1)}
        {renderSquare(2)}
        {renderSquare(3)}
        {renderSquare(4)}
        {renderSquare(5)}
        {renderSquare(6)}
        {renderSquare(7)}
        {renderSquare(8)}
      </div>
      <button
        className="w-full mt-10 py-3 bg-blue-500 text-white font-bold rounded hover:bg-blue-700"
        onClick={restart}
      >
        Restart
      </button>
    </div>
  );
}

function Game() {
  return (
    <div className="flex justify-center items-center h-screen bg-[#0F1B21]">
      <Board />
    </div>
  );
}

function App() {
  return <Game />;
}

export default App;